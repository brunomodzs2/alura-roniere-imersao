// Importa a biblioteca do Google Generative AI
const { GoogleGenerativeAI } = require("@google/generative-ai");

// Cria uma instância do Google Generative AI com a chave de API fornecida como uma variável de ambiente
const genAI = new GoogleGenerativeAI(process.env.API_KEY);

// Função assíncrona para executar a geração de texto
async function process_text_gemini(text, message) {
  // Para entrada de texto, use o modelo text-bison-001
  const model = genAI.getGenerativeModel({ model: "text-bison-001" });

  // Gera o conteúdo usando o modelo e o texto fornecido
  const result = await model.generateContent([text]);

  // Obtém a resposta da API
  const response = await result.response;

  // Obtém o texto gerado
  const generatedText = response.text();

  // Envia o texto gerado de volta para o cliente
  message.send(generatedText);
}