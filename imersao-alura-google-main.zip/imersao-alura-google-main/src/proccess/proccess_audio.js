// Importa a biblioteca do ChatGPT
const ChatGPTAPI = require('openai');
const { Configuration, OpenAIApi } = ChatGPTAPI;

// Cria uma configuração para a API do ChatGPT
const configuration = new Configuration({
  apiKey: process.env.CHATGPT_API_KEY,
});

// Cria uma instância da API do ChatGPT
const openai = new OpenAIApi(configuration);

// Função assíncrona para processar o áudio
async function process_audio(base64Audio) {
  // Converte o áudio base64 em um prompt de texto para o ChatGPT
  const prompt = `Transcreva este áudio para mim: ${base64Audio}`;

  // Envia o prompt para o ChatGPT
  const response = await openai.createCompletion({
    prompt: {
      text: prompt,
    },
  });

  // Obtém a transcrição de texto do ChatGPT
  const transcription = response.data.candidates[0].output;

  // Envia a transcrição para o processamento de texto Gemini
  process_text_gemini(transcription);
}